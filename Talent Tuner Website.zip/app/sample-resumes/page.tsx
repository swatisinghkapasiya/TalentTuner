import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { SampleResumes as SampleResumesComponent } from "@/components/sample-resumes"

export default function SampleResumesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-violet-600 to-indigo-700 py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-4xl md:text-5xl">
                Browse <span className="text-cyan-300">Sample Resumes</span>
              </h1>
              <p className="mt-4 text-white/90 md:text-xl">
                Get inspired by industry-approved resume samples for various job roles and experience levels.
              </p>
            </div>
          </div>
        </section>

        {/* Sample Resumes Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-6xl">
              <SampleResumesComponent />
            </div>
          </div>
        </section>

        {/* Tips Section */}
        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">
              Resume Writing <span className="text-violet-600">Tips & Best Practices</span>
            </h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  title: "Tailor to the Job",
                  description:
                    "Customize your resume for each job application by highlighting relevant skills and experiences.",
                },
                {
                  title: "Use Action Verbs",
                  description:
                    "Start bullet points with strong action verbs like 'achieved,' 'implemented,' or 'managed.'",
                },
                {
                  title: "Quantify Achievements",
                  description:
                    "Include numbers and percentages to demonstrate the impact of your work whenever possible.",
                },
                {
                  title: "Keep it Concise",
                  description: "Aim for a one-page resume unless you have extensive relevant experience.",
                },
                {
                  title: "Include Keywords",
                  description: "Incorporate industry-specific keywords from the job description to pass ATS systems.",
                },
                {
                  title: "Proofread Carefully",
                  description:
                    "Eliminate spelling and grammar errors that can make a negative impression on employers.",
                },
              ].map((tip, index) => (
                <Card key={index} className="overflow-hidden transition-all hover:border-violet-300 hover:shadow-md">
                  <CardContent className="p-6">
                    <h3 className="mb-2 text-xl font-medium">{tip.title}</h3>
                    <p className="text-muted-foreground">{tip.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl rounded-lg bg-gradient-to-br from-violet-600 to-indigo-700 p-8 text-center text-white md:p-12">
              <h2 className="text-2xl font-bold md:text-3xl">Ready to Create Your Own Resume?</h2>
              <p className="mt-4 text-white/90">
                Use our templates and AI-powered tools to build a professional resume that stands out.
              </p>
              <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:justify-center">
                <Button size="lg" className="bg-cyan-500 hover:bg-cyan-600">
                  Build Your Resume
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/30 bg-white/10 text-white backdrop-blur-sm hover:bg-white/20"
                >
                  Try Resume Analyzer
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
