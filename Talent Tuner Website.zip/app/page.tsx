import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, BarChart2, CheckCircle, FileText, Search, Zap, Award, Briefcase } from "lucide-react"
import { ResumeAnalyzerDemo } from "@/components/resume-analyzer-demo"
import { FeatureCard } from "@/components/feature-card"
import { HowItWorks } from "@/components/how-it-works"
import { SampleResumes } from "@/components/sample-resumes"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import Link from "next/link"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-violet-600 to-indigo-700 py-20 md:py-32">
          <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:60px_60px]" />
          <div className="container relative z-10 px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <Badge className="inline-flex items-center rounded-full border border-white/20 bg-white/10 px-3 py-1 text-sm font-medium text-white backdrop-blur-sm">
                    <Zap className="mr-1 h-3.5 w-3.5" />
                    Your Personalized Resume Builder & Analyzer
                  </Badge>
                  <h1 className="text-4xl font-bold tracking-tighter text-white sm:text-5xl md:text-6xl">
                    Land Your Dream Job with <span className="text-cyan-300">Talent Tuner</span>
                  </h1>
                  <p className="max-w-[600px] text-white/90 md:text-xl">
                    Build professional resumes and analyze them against job requirements to increase your chances of
                    getting hired.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" className="bg-cyan-500 text-white hover:bg-cyan-600" asChild>
                    <Link href="/resume-builder">
                      Build Your Resume
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white/30 bg-white/10 text-white backdrop-blur-sm hover:bg-white/20"
                    asChild
                  >
                    <Link href="/resume-analyzer">Try Resume Analyzer</Link>
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative h-[350px] w-full max-w-[500px] overflow-hidden rounded-lg border border-white/20 bg-white/10 p-1 backdrop-blur-sm">
                  <div className="absolute inset-0 bg-gradient-to-br from-violet-600/20 to-cyan-500/20" />
                  <div className="relative h-full w-full overflow-hidden rounded-md bg-white">
                    <div className="flex h-8 items-center gap-2 border-b bg-gray-50 px-3">
                      <div className="h-3 w-3 rounded-full bg-red-400" />
                      <div className="h-3 w-3 rounded-full bg-yellow-400" />
                      <div className="h-3 w-3 rounded-full bg-green-400" />
                      <div className="ml-2 text-xs text-gray-500">Resume Preview</div>
                    </div>
                    <div className="grid h-[calc(100%-32px)] grid-cols-[2fr_1fr] gap-4 p-4">
                      <div className="space-y-3">
                        <div className="h-8 w-3/4 rounded bg-gray-200" />
                        <div className="h-4 w-1/2 rounded bg-gray-200" />
                        <div className="h-4 w-full rounded bg-gray-200" />
                        <div className="h-4 w-full rounded bg-gray-200" />
                        <div className="h-6 w-1/3 rounded bg-gray-200" />
                        <div className="space-y-2">
                          <div className="h-3 w-full rounded bg-gray-200" />
                          <div className="h-3 w-full rounded bg-gray-200" />
                          <div className="h-3 w-4/5 rounded bg-gray-200" />
                        </div>
                        <div className="h-6 w-1/3 rounded bg-gray-200" />
                        <div className="space-y-2">
                          <div className="h-3 w-full rounded bg-gray-200" />
                          <div className="h-3 w-full rounded bg-gray-200" />
                          <div className="h-3 w-4/5 rounded bg-gray-200" />
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="h-6 w-full rounded bg-violet-200" />
                        <div className="space-y-1">
                          <div className="h-3 w-full rounded bg-gray-200" />
                          <div className="h-3 w-full rounded bg-gray-200" />
                        </div>
                        <div className="h-6 w-full rounded bg-cyan-200" />
                        <div className="space-y-1">
                          <div className="h-3 w-full rounded bg-gray-200" />
                          <div className="h-3 w-full rounded bg-gray-200" />
                          <div className="h-3 w-full rounded bg-gray-200" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                Powerful Features to <span className="text-violet-600">Boost Your Career</span>
              </h2>
              <p className="max-w-[85%] text-muted-foreground md:text-xl">
                Our intelligent tools help you create professional resumes and analyze them against job requirements.
              </p>
            </div>
            <div className="mx-auto mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <FeatureCard
                icon={<FileText className="h-10 w-10 text-violet-600" />}
                title="Smart Templates"
                description="Access professionally designed resume templates tailored to specific industries and job roles."
              />
              <FeatureCard
                icon={<BarChart2 className="h-10 w-10 text-violet-600" />}
                title="Resume Analyzer"
                description="AI-powered analysis that evaluates your resume against job descriptions and provides actionable feedback."
              />
              <FeatureCard
                icon={<Search className="h-10 w-10 text-violet-600" />}
                title="Keyword Optimization"
                description="Identify and incorporate industry-specific keywords to pass through ATS systems."
              />
              <FeatureCard
                icon={<CheckCircle className="h-10 w-10 text-violet-600" />}
                title="Skills Assessment"
                description="Evaluate your skills against job requirements and get suggestions for improvement."
              />
              <FeatureCard
                icon={<Award className="h-10 w-10 text-violet-600" />}
                title="Sample Resumes"
                description="Browse through industry-approved resume samples categorized by job roles."
              />
              <FeatureCard
                icon={<Briefcase className="h-10 w-10 text-violet-600" />}
                title="Job Match Score"
                description="Get a personalized score that reflects how well your resume matches specific job requirements."
              />
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="bg-gray-50 py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                How <span className="text-violet-600">Talent Tuner</span> Works
              </h2>
              <p className="max-w-[85%] text-muted-foreground md:text-xl">
                A simple yet powerful process to create and optimize your resume
              </p>
            </div>
            <HowItWorks />
          </div>
        </section>

        {/* Resume Analyzer Demo */}
        <section className="py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                Try Our <span className="text-violet-600">Resume Analyzer</span>
              </h2>
              <p className="max-w-[85%] text-muted-foreground md:text-xl">
                Upload your resume and a job description to see how well they match
              </p>
            </div>
            <div className="mx-auto mt-12 max-w-5xl">
              <ResumeAnalyzerDemo />
            </div>
          </div>
        </section>

        {/* Sample Resumes Section */}
        <section className="bg-gray-50 py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                Browse <span className="text-violet-600">Sample Resumes</span>
              </h2>
              <p className="max-w-[85%] text-muted-foreground md:text-xl">
                Get inspired by industry-approved resume samples for various job roles
              </p>
            </div>
            <div className="mx-auto mt-12 max-w-6xl">
              <SampleResumes />
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-violet-600 to-indigo-700 py-16 md:py-24">
          <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:60px_60px]" />
          <div className="container relative z-10 px-4 md:px-6">
            <div className="mx-auto flex max-w-3xl flex-col items-center justify-center gap-4 text-center">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl md:text-5xl">
                Ready to Land Your Dream Job?
              </h2>
              <p className="max-w-[85%] text-white/90 md:text-xl">
                Join thousands of job seekers who have successfully improved their resumes and landed interviews with
                Talent Tuner.
              </p>
              <div className="mt-4 flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" className="bg-cyan-500 text-white hover:bg-cyan-600" asChild>
                  <Link href="/resume-builder">
                    Get Started for Free
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/30 bg-white/10 text-white backdrop-blur-sm hover:bg-white/20"
                  asChild
                >
                  <Link href="/pricing">View Pricing Plans</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
