import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, FileText, Layout, Briefcase } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function ResumeBuilder() {
  const templates = [
    { id: "modern", name: "Modern", icon: <Layout className="h-10 w-10 text-violet-600" /> },
    { id: "professional", name: "Professional", icon: <Briefcase className="h-10 w-10 text-violet-600" /> },
    { id: "creative", name: "Creative", icon: <FileText className="h-10 w-10 text-violet-600" /> },
  ]

  const industries = [
    { id: "tech", name: "Technology" },
    { id: "business", name: "Business" },
    { id: "creative", name: "Creative" },
    { id: "healthcare", name: "Healthcare" },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-violet-600 to-indigo-700 py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-4xl md:text-5xl">
                Build Your Professional <span className="text-cyan-300">Resume</span>
              </h1>
              <p className="mt-4 text-white/90 md:text-xl">
                Create a standout resume with our smart templates tailored to your industry and job role.
              </p>
            </div>
          </div>
        </section>

        {/* Job Role Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl">
              <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">Select Your Job Role</h2>
              <div className="rounded-lg border p-4">
                <div className="mb-4">
                  <label htmlFor="job-role" className="mb-2 block text-sm font-medium">
                    Job Role or Position
                  </label>
                  <input
                    type="text"
                    id="job-role"
                    placeholder="e.g., Software Engineer, Marketing Manager, etc."
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  />
                </div>
                <div className="mb-4">
                  <label htmlFor="experience" className="mb-2 block text-sm font-medium">
                    Experience Level
                  </label>
                  <select
                    id="experience"
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  >
                    <option value="">Select experience level</option>
                    <option value="entry">Entry Level (0-2 years)</option>
                    <option value="mid">Mid Level (3-5 years)</option>
                    <option value="senior">Senior Level (6+ years)</option>
                  </select>
                </div>
                <Button className="w-full bg-violet-600 hover:bg-violet-700">
                  Find Templates
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Templates Section */}
        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">Choose a Template Style</h2>

            <Tabs defaultValue="tech" className="mx-auto max-w-4xl">
              <TabsList className="mb-8 w-full justify-center">
                {industries.map((industry) => (
                  <TabsTrigger key={industry.id} value={industry.id} className="min-w-[120px]">
                    {industry.name}
                  </TabsTrigger>
                ))}
              </TabsList>

              {industries.map((industry) => (
                <TabsContent key={industry.id} value={industry.id}>
                  <div className="grid gap-6 md:grid-cols-3">
                    {templates.map((template) => (
                      <Card
                        key={template.id}
                        className="overflow-hidden transition-all hover:border-violet-300 hover:shadow-md"
                      >
                        <CardContent className="p-0">
                          <div className="flex h-40 items-center justify-center border-b bg-gray-50">
                            {template.icon}
                          </div>
                          <div className="p-4">
                            <h3 className="text-lg font-medium">{template.name}</h3>
                            <p className="mt-1 text-sm text-muted-foreground">
                              Perfect for {industry.name.toLowerCase()} professionals
                            </p>
                            <Button className="mt-4 w-full bg-violet-600 hover:bg-violet-700">Use This Template</Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl rounded-lg bg-gradient-to-br from-violet-600 to-indigo-700 p-8 text-center text-white md:p-12">
              <h2 className="text-2xl font-bold md:text-3xl">Ready to Build Your Professional Resume?</h2>
              <p className="mt-4 text-white/90">
                Our smart templates and AI-powered suggestions will help you create a resume that stands out.
              </p>
              <Button size="lg" className="mt-6 bg-cyan-500 hover:bg-cyan-600">
                Get Started Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
