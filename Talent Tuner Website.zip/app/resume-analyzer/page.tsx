import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Upload, FileText, BarChart2 } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ResumeAnalyzerDemo } from "@/components/resume-analyzer-demo"

export default function ResumeAnalyzer() {
  const features = [
    {
      title: "Job Match Analysis",
      description: "Compare your resume against specific job descriptions to see how well you match the requirements.",
      icon: <BarChart2 className="h-10 w-10 text-violet-600" />,
    },
    {
      title: "Keyword Optimization",
      description: "Identify missing keywords and phrases that are important for passing ATS systems.",
      icon: <FileText className="h-10 w-10 text-violet-600" />,
    },
    {
      title: "Improvement Suggestions",
      description:
        "Get personalized recommendations to enhance your resume and increase your chances of getting hired.",
      icon: <Upload className="h-10 w-10 text-violet-600" />,
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-violet-600 to-indigo-700 py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-4xl md:text-5xl">
                AI-Powered <span className="text-cyan-300">Resume Analyzer</span>
              </h1>
              <p className="mt-4 text-white/90 md:text-xl">
                Analyze your resume against job descriptions and get personalized feedback to improve your chances of
                getting hired.
              </p>
              <Button size="lg" className="mt-8 bg-cyan-500 text-white hover:bg-cyan-600">
                Analyze My Resume
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">
              How Our <span className="text-violet-600">Resume Analyzer</span> Helps You
            </h2>
            <div className="grid gap-6 md:grid-cols-3">
              {features.map((feature, index) => (
                <Card key={index} className="overflow-hidden transition-all hover:border-violet-300 hover:shadow-md">
                  <CardContent className="p-6">
                    <div className="mb-4">{feature.icon}</div>
                    <h3 className="mb-2 text-xl font-medium">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Demo Section */}
        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Try Our <span className="text-violet-600">Resume Analyzer</span>
              </h2>
              <p className="max-w-[85%] text-muted-foreground md:text-xl">
                Upload your resume and a job description to see how well they match
              </p>
            </div>
            <div className="mx-auto mt-12 max-w-5xl">
              <ResumeAnalyzerDemo />
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">What Our Users Say</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg
                          key={star}
                          className="h-5 w-5 fill-current text-yellow-500"
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                        </svg>
                      ))}
                    </div>
                    <p className="mt-4 text-muted-foreground">
                      "The resume analyzer helped me identify key missing skills in my resume. After making the
                      suggested changes, I got called for an interview within a week!"
                    </p>
                    <div className="mt-6 flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-gray-200"></div>
                      <div>
                        <p className="font-medium">Sarah Johnson</p>
                        <p className="text-sm text-muted-foreground">Software Developer</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-gradient-to-br from-violet-600 to-indigo-700 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Ready to Optimize Your Resume?
              </h2>
              <p className="mt-4 text-white/90 md:text-xl">
                Get personalized feedback and increase your chances of landing your dream job.
              </p>
              <Button size="lg" className="mt-8 bg-cyan-500 text-white hover:bg-cyan-600">
                Analyze My Resume Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
