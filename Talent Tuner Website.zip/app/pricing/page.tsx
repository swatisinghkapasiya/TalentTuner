import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, ArrowRight } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function Pricing() {
  const plans = [
    {
      name: "Free",
      price: "$0",
      description: "Basic resume building tools for getting started",
      features: [
        "1 resume template",
        "Basic resume builder",
        "Limited resume analyzer",
        "Export to PDF",
        "Email support",
      ],
      cta: "Get Started",
      popular: false,
    },
    {
      name: "Pro",
      price: "$12",
      period: "per month",
      description: "Advanced tools for job seekers",
      features: [
        "All resume templates",
        "Advanced resume builder",
        "Full resume analyzer",
        "Keyword optimization",
        "Export to multiple formats",
        "Priority support",
      ],
      cta: "Get Pro",
      popular: true,
    },
    {
      name: "Enterprise",
      price: "$29",
      period: "per month",
      description: "Complete solution for professionals",
      features: [
        "All Pro features",
        "Multiple resume versions",
        "Cover letter builder",
        "LinkedIn profile optimization",
        "Interview preparation tools",
        "24/7 priority support",
      ],
      cta: "Contact Sales",
      popular: false,
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-violet-600 to-indigo-700 py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-4xl md:text-5xl">
                Simple, Transparent <span className="text-cyan-300">Pricing</span>
              </h1>
              <p className="mt-4 text-white/90 md:text-xl">
                Choose the plan that's right for you and start building your professional resume today.
              </p>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl gap-6 md:grid-cols-3">
              {plans.map((plan, index) => (
                <Card
                  key={index}
                  className={`flex flex-col overflow-hidden ${
                    plan.popular
                      ? "relative border-violet-600 shadow-lg"
                      : "transition-all hover:border-violet-300 hover:shadow-md"
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute right-0 top-0 rounded-bl-lg bg-violet-600 px-3 py-1 text-xs font-medium text-white">
                      Most Popular
                    </div>
                  )}
                  <CardHeader className={plan.popular ? "pb-8 pt-10" : ""}>
                    <CardTitle>{plan.name}</CardTitle>
                    <div className="mt-4 flex items-baseline text-3xl font-bold">
                      {plan.price}
                      {plan.period && (
                        <span className="ml-1 text-sm font-normal text-muted-foreground">{plan.period}</span>
                      )}
                    </div>
                    <CardDescription className="mt-2">{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-center">
                          <Check className="mr-2 h-4 w-4 text-green-500" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className={`w-full ${
                        plan.popular ? "bg-violet-600 hover:bg-violet-700" : "bg-violet-600/90 hover:bg-violet-600"
                      }`}
                    >
                      {plan.cta}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <h2 className="mb-8 text-center text-2xl font-bold md:text-3xl">Frequently Asked Questions</h2>
            <div className="mx-auto max-w-3xl space-y-4">
              {[
                {
                  question: "Can I cancel my subscription at any time?",
                  answer:
                    "Yes, you can cancel your subscription at any time. Your plan will remain active until the end of the current billing period.",
                },
                {
                  question: "Is there a limit to how many resumes I can create?",
                  answer:
                    "Free users can create 1 resume, Pro users can create up to 5 resumes, and Enterprise users have unlimited resumes.",
                },
                {
                  question: "How does the resume analyzer work?",
                  answer:
                    "Our AI-powered resume analyzer compares your resume against job descriptions to identify missing keywords, skills, and other improvements to increase your chances of getting hired.",
                },
                {
                  question: "Can I export my resume to different formats?",
                  answer:
                    "Yes, depending on your plan. Free users can export to PDF, while paid plans allow export to multiple formats including PDF, DOCX, and TXT.",
                },
                {
                  question: "Do you offer refunds?",
                  answer:
                    "We offer a 14-day money-back guarantee for all paid plans. If you're not satisfied with our service, contact our support team for a full refund.",
                },
              ].map((faq, index) => (
                <Card key={index} className="overflow-hidden">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">{faq.question}</h3>
                    <p className="mt-2 text-muted-foreground">{faq.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-16">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl rounded-lg bg-gradient-to-br from-violet-600 to-indigo-700 p-8 text-center text-white md:p-12">
              <h2 className="text-2xl font-bold md:text-3xl">Ready to Land Your Dream Job?</h2>
              <p className="mt-4 text-white/90">
                Join thousands of job seekers who have successfully improved their resumes and landed interviews with
                Talent Tuner.
              </p>
              <Button size="lg" className="mt-6 bg-cyan-500 hover:bg-cyan-600">
                Get Started for Free
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
