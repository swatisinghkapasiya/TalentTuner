import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Twitter, Instagram, Linkedin, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container px-4 py-12 md:px-6 md:py-16">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="relative h-8 w-8 overflow-hidden rounded-full bg-gradient-to-br from-violet-600 to-cyan-500">
                <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-lg">TT</div>
              </div>
              <span className="text-xl font-bold">Talent Tuner</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Your personalized resume builder and analyzer to help you land your dream job.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-muted-foreground hover:text-violet-600">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-violet-600">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-violet-600">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-violet-600">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Product</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/resume-builder" className="text-muted-foreground hover:text-violet-600">
                  Resume Builder
                </Link>
              </li>
              <li>
                <Link href="/resume-analyzer" className="text-muted-foreground hover:text-violet-600">
                  Resume Analyzer
                </Link>
              </li>
              <li>
                <Link href="/sample-resumes" className="text-muted-foreground hover:text-violet-600">
                  Sample Resumes
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-violet-600">
                  Templates
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-muted-foreground hover:text-violet-600">
                  Pricing
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Company</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-violet-600">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-violet-600">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-violet-600">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-violet-600">
                  Press
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-violet-600">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Subscribe</h3>
            <p className="text-sm text-muted-foreground">Get the latest news and updates from Talent Tuner.</p>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input type="email" placeholder="Enter your email" />
              <Button className="bg-violet-600 text-white hover:bg-violet-700">
                <Mail className="mr-2 h-4 w-4" />
                Subscribe
              </Button>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t pt-6">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Talent Tuner. All rights reserved.
            </p>
            <div className="flex gap-4 text-sm">
              <Link href="#" className="text-muted-foreground hover:text-violet-600">
                Terms of Service
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-violet-600">
                Privacy Policy
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-violet-600">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
