"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search, FileText, Download, Eye } from "lucide-react"

export function SampleResumes() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = [
    { id: "tech", name: "Technology" },
    { id: "business", name: "Business" },
    { id: "creative", name: "Creative" },
    { id: "healthcare", name: "Healthcare" },
  ]

  const sampleResumes = {
    tech: [
      { id: 1, title: "Senior Software Engineer", level: "Senior", downloads: 2345 },
      { id: 2, title: "Frontend Developer", level: "Mid", downloads: 1876 },
      { id: 3, title: "Data Scientist", level: "Senior", downloads: 1543 },
      { id: 4, title: "DevOps Engineer", level: "Mid", downloads: 1298 },
      { id: 5, title: "UX/UI Designer", level: "Junior", downloads: 2109 },
      { id: 6, title: "Product Manager", level: "Senior", downloads: 1765 },
    ],
    business: [
      { id: 7, title: "Marketing Manager", level: "Senior", downloads: 1432 },
      { id: 8, title: "Financial Analyst", level: "Mid", downloads: 1287 },
      { id: 9, title: "Business Development", level: "Senior", downloads: 1654 },
      { id: 10, title: "Project Manager", level: "Mid", downloads: 1876 },
    ],
    creative: [
      { id: 11, title: "Graphic Designer", level: "Mid", downloads: 2109 },
      { id: 12, title: "Content Writer", level: "Junior", downloads: 1543 },
      { id: 13, title: "Video Editor", level: "Senior", downloads: 1298 },
      { id: 14, title: "Social Media Manager", level: "Mid", downloads: 1765 },
    ],
    healthcare: [
      { id: 15, title: "Registered Nurse", level: "Senior", downloads: 1432 },
      { id: 16, title: "Medical Assistant", level: "Junior", downloads: 1287 },
      { id: 17, title: "Healthcare Administrator", level: "Senior", downloads: 1654 },
      { id: 18, title: "Physical Therapist", level: "Mid", downloads: 1876 },
    ],
  }

  const filterResumes = (category) => {
    if (!searchQuery) return sampleResumes[category]

    return sampleResumes[category].filter(
      (resume) =>
        resume.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        resume.level.toLowerCase().includes(searchQuery.toLowerCase()),
    )
  }

  return (
    <div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search by job title or level..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button className="bg-violet-600 hover:bg-violet-700">Browse All Samples</Button>
      </div>

      <Tabs defaultValue="tech">
        <TabsList className="mb-4 w-full justify-start overflow-auto">
          {categories.map((category) => (
            <TabsTrigger key={category.id} value={category.id} className="min-w-[120px]">
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {categories.map((category) => (
          <TabsContent key={category.id} value={category.id}>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filterResumes(category.id).map((resume) => (
                <Card
                  key={resume.id}
                  className="overflow-hidden transition-all hover:border-violet-300 hover:shadow-md"
                >
                  <CardContent className="p-0">
                    <div className="flex h-32 items-center justify-center border-b bg-gray-50">
                      <div className="flex h-20 w-16 flex-col items-center justify-center rounded border bg-white shadow-sm">
                        <FileText className="h-8 w-8 text-violet-600" />
                        <div className="mt-1 text-xs font-medium">Resume</div>
                      </div>
                    </div>
                    <div className="p-4">
                      <h4 className="font-medium">{resume.title}</h4>
                      <div className="mt-1 flex items-center justify-between">
                        <span className="rounded-full bg-violet-100 px-2 py-0.5 text-xs font-medium text-violet-800">
                          {resume.level} Level
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {resume.downloads.toLocaleString()} downloads
                        </span>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="mr-1 h-3.5 w-3.5" />
                          Preview
                        </Button>
                        <Button size="sm" className="flex-1 bg-violet-600 hover:bg-violet-700">
                          <Download className="mr-1 h-3.5 w-3.5" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filterResumes(category.id).length === 0 && (
              <div className="flex h-40 flex-col items-center justify-center rounded-lg border bg-gray-50 text-center">
                <Search className="h-8 w-8 text-muted-foreground" />
                <p className="mt-2 text-muted-foreground">No resumes found matching your search criteria</p>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
