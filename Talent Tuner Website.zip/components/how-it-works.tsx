import { FileText, Upload, Search, BarChart2, CheckCircle } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: <FileText className="h-10 w-10 text-white" />,
      title: "Select Job Role",
      description: "Choose the job role or position you're applying for to get tailored templates and recommendations.",
    },
    {
      icon: <Upload className="h-10 w-10 text-white" />,
      title: "Build or Upload Resume",
      description: "Create a new resume using our smart templates or upload your existing resume for analysis.",
    },
    {
      icon: <Search className="h-10 w-10 text-white" />,
      title: "Add Job Description",
      description: "Input the job description to allow our AI to analyze requirements and expectations.",
    },
    {
      icon: <BarChart2 className="h-10 w-10 text-white" />,
      title: "Get Analysis",
      description: "Receive a detailed analysis of how well your resume matches the job requirements.",
    },
    {
      icon: <CheckCircle className="h-10 w-10 text-white" />,
      title: "Optimize & Apply",
      description: "Make the suggested improvements to your resume and increase your chances of landing an interview.",
    },
  ]

  return (
    <div className="mt-12">
      <div className="relative mx-auto max-w-5xl">
        {/* Connecting line */}
        <div className="absolute left-1/2 top-0 h-full w-0.5 -translate-x-1/2 bg-gradient-to-b from-violet-600 to-cyan-500 md:left-[80px] md:translate-x-0" />

        {/* Steps */}
        <div className="space-y-12 md:space-y-16">
          {steps.map((step, index) => (
            <div key={index} className="relative flex flex-col items-center md:flex-row md:items-start md:gap-8">
              {/* Icon */}
              <div className="z-10 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-violet-600 to-cyan-500 shadow-lg">
                {step.icon}
                <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-white text-sm font-bold text-violet-600 shadow">
                  {index + 1}
                </span>
              </div>

              {/* Content */}
              <div className="mt-4 text-center md:mt-0 md:flex-1 md:text-left">
                <h3 className="text-xl font-bold">{step.title}</h3>
                <p className="mt-2 text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
