"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AlignJustify, X, FileText, BarChart2, User, LogIn } from "lucide-react"

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <div className="relative h-8 w-8 overflow-hidden rounded-full bg-gradient-to-br from-violet-600 to-cyan-500">
            <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-lg">TT</div>
          </div>
          <span className="text-xl font-bold">Talent Tuner</span>
        </Link>
        <nav className="hidden gap-6 md:flex">
          <Link href="/resume-builder" className="text-sm font-medium hover:text-violet-600">
            Resume Builder
          </Link>
          <Link href="/resume-analyzer" className="text-sm font-medium hover:text-violet-600">
            Resume Analyzer
          </Link>
          <Link href="/sample-resumes" className="text-sm font-medium hover:text-violet-600">
            Sample Resumes
          </Link>
          <Link href="/pricing" className="text-sm font-medium hover:text-violet-600">
            Pricing
          </Link>
        </nav>
        <div className="hidden md:flex md:items-center md:gap-4">
          <Button variant="ghost" size="sm">
            <LogIn className="mr-2 h-4 w-4" />
            Log In
          </Button>
          <Button size="sm" className="bg-violet-600 text-white hover:bg-violet-700">
            Sign Up Free
          </Button>
        </div>
        <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6" /> : <AlignJustify className="h-6 w-6" />}
          <span className="sr-only">Toggle menu</span>
        </Button>
      </div>
      {isMenuOpen && (
        <div className="container md:hidden">
          <nav className="flex flex-col gap-4 p-4">
            <Link
              href="/resume-builder"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium hover:bg-violet-50 hover:text-violet-600"
              onClick={() => setIsMenuOpen(false)}
            >
              <FileText className="h-5 w-5" />
              Resume Builder
            </Link>
            <Link
              href="/resume-analyzer"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium hover:bg-violet-50 hover:text-violet-600"
              onClick={() => setIsMenuOpen(false)}
            >
              <BarChart2 className="h-5 w-5" />
              Resume Analyzer
            </Link>
            <Link
              href="/sample-resumes"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium hover:bg-violet-50 hover:text-violet-600"
              onClick={() => setIsMenuOpen(false)}
            >
              <User className="h-5 w-5" />
              Sample Resumes
            </Link>
            <Link
              href="/pricing"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium hover:bg-violet-50 hover:text-violet-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Pricing
            </Link>
            <div className="flex flex-col gap-2 pt-2">
              <Button variant="outline" size="sm" className="w-full justify-start">
                <LogIn className="mr-2 h-4 w-4" />
                Log In
              </Button>
              <Button size="sm" className="w-full justify-start bg-violet-600 text-white hover:bg-violet-700">
                Sign Up Free
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
