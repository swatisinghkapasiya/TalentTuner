"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Upload, FileText, CheckCircle, AlertCircle, BarChart2, ChevronRight } from "lucide-react"

export function ResumeAnalyzerDemo() {
  const [step, setStep] = useState(1)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [progress, setProgress] = useState(0)
  const [jobDescription, setJobDescription] = useState("")
  const [fileName, setFileName] = useState("")

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileName(e.target.files[0].name)
    }
  }

  const handleAnalyze = () => {
    if (step === 1 && fileName) {
      setStep(2)
    } else if (step === 2 && jobDescription) {
      setStep(3)
      setIsAnalyzing(true)

      // Simulate analysis progress
      let currentProgress = 0
      const interval = setInterval(() => {
        currentProgress += 5
        setProgress(currentProgress)

        if (currentProgress >= 100) {
          clearInterval(interval)
          setIsAnalyzing(false)
          setIsComplete(true)
        }
      }, 150)
    }
  }

  const handleReset = () => {
    setStep(1)
    setIsAnalyzing(false)
    setIsComplete(false)
    setProgress(0)
    setJobDescription("")
    setFileName("")
  }

  return (
    <Card className="overflow-hidden border-2">
      <CardContent className="p-0">
        <div className="grid md:grid-cols-[1fr_1.5fr]">
          {/* Input Section */}
          <div className="border-b p-6 md:border-b-0 md:border-r">
            <div className="mb-6 flex items-center gap-2 text-lg font-semibold">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-violet-600 text-xs text-white">
                {step}
              </span>
              {step === 1 && "Upload Your Resume"}
              {step === 2 && "Add Job Description"}
              {step === 3 && (isAnalyzing ? "Analyzing..." : "Analysis Results")}
            </div>

            {step === 1 && (
              <div className="space-y-4">
                <div className="flex flex-col items-center justify-center gap-4 rounded-lg border-2 border-dashed border-gray-200 p-8 text-center">
                  <div className="rounded-full bg-violet-100 p-3">
                    <Upload className="h-6 w-6 text-violet-600" />
                  </div>
                  <div>
                    <p className="font-medium">Upload your resume</p>
                    <p className="text-sm text-muted-foreground">PDF, DOCX or TXT (Max 5MB)</p>
                  </div>
                  <label className="w-full cursor-pointer">
                    <Button className="w-full bg-violet-600 hover:bg-violet-700">Select File</Button>
                    <input type="file" className="hidden" accept=".pdf,.docx,.txt" onChange={handleFileUpload} />
                  </label>
                </div>
                {fileName && (
                  <div className="flex items-center gap-2 rounded-lg border bg-gray-50 p-3">
                    <FileText className="h-5 w-5 text-violet-600" />
                    <span className="text-sm font-medium">{fileName}</span>
                  </div>
                )}
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <Textarea
                  placeholder="Paste the job description here..."
                  className="min-h-[200px] resize-none"
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  For best results, include the full job description with requirements and qualifications.
                </p>
              </div>
            )}

            {step === 3 && isAnalyzing && (
              <div className="space-y-6 py-8 text-center">
                <div className="mx-auto h-16 w-16 animate-pulse rounded-full bg-violet-100 p-4">
                  <BarChart2 className="h-8 w-8 text-violet-600" />
                </div>
                <div>
                  <p className="font-medium">Analyzing your resume...</p>
                  <p className="text-sm text-muted-foreground">This will take just a moment</p>
                </div>
                <Progress value={progress} className="h-2 w-full" />
              </div>
            )}

            {step === 3 && isComplete && (
              <div className="space-y-4">
                <div className="rounded-lg bg-green-50 p-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <p className="font-medium text-green-800">Analysis Complete!</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  View your detailed results on the right. We've analyzed your resume against the job description and
                  provided recommendations.
                </p>
                <Button variant="outline" className="w-full" onClick={handleReset}>
                  Start New Analysis
                </Button>
              </div>
            )}

            {step < 3 && (
              <Button
                className="mt-6 w-full bg-violet-600 hover:bg-violet-700"
                disabled={step === 1 ? !fileName : !jobDescription}
                onClick={handleAnalyze}
              >
                {step === 1 ? "Continue" : "Analyze Resume"}
                <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Results Section */}
          <div className="bg-gray-50 p-6">
            <h3 className="mb-4 text-lg font-semibold">Resume Analysis</h3>

            {!isComplete ? (
              <div className="flex h-[300px] flex-col items-center justify-center gap-4 text-center">
                <div className="rounded-full bg-gray-200 p-3">
                  <BarChart2 className="h-6 w-6 text-gray-400" />
                </div>
                <div>
                  <p className="font-medium text-gray-500">No Analysis Yet</p>
                  <p className="text-sm text-muted-foreground">
                    Upload your resume and add a job description to see your analysis results here.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Match Score */}
                <div className="rounded-lg border bg-white p-4">
                  <h4 className="mb-2 font-medium">Overall Match Score</h4>
                  <div className="flex items-center gap-4">
                    <div className="relative h-16 w-16">
                      <div className="absolute inset-0 flex items-center justify-center text-lg font-bold text-violet-600">
                        72%
                      </div>
                      <svg className="h-full w-full" viewBox="0 0 36 36">
                        <path
                          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="#E2E8F0"
                          strokeWidth="3"
                        />
                        <path
                          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                          fill="none"
                          stroke="#8B5CF6"
                          strokeWidth="3"
                          strokeDasharray="72, 100"
                          strokeLinecap="round"
                        />
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm">Your resume matches 72% of the job requirements</p>
                      <p className="text-xs text-muted-foreground">Good match, with room for improvement</p>
                    </div>
                  </div>
                </div>

                {/* Key Findings */}
                <div>
                  <h4 className="mb-2 font-medium">Key Findings</h4>
                  <div className="space-y-2">
                    <div className="rounded-lg border bg-white p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                        <div>
                          <p className="text-sm font-medium">Strong skills match</p>
                          <p className="text-xs text-muted-foreground">
                            Your technical skills align well with the job requirements
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-lg border bg-white p-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                        <div>
                          <p className="text-sm font-medium">Experience level match</p>
                          <p className="text-xs text-muted-foreground">
                            Your experience level meets the job requirements
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-lg border bg-white p-3">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                        <div>
                          <p className="text-sm font-medium">Missing keywords</p>
                          <p className="text-xs text-muted-foreground">
                            Add keywords: "project management", "agile methodology"
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-lg border bg-white p-3">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                        <div>
                          <p className="text-sm font-medium">Quantify achievements</p>
                          <p className="text-xs text-muted-foreground">
                            Add metrics to demonstrate impact in your work experience
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <Button className="w-full bg-violet-600 hover:bg-violet-700">View Full Analysis Report</Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
